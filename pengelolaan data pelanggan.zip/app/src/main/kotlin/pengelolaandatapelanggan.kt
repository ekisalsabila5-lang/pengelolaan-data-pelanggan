package org.example.app

import java.awt.BorderLayout
import java.awt.FlowLayout
import java.awt.GridLayout
import java.awt.event.ActionEvent
import javax.swing.*
import javax.swing.table.DefaultTableModel

class PengelolaanDataPelangganV2 : JFrame() {
    private val txtNama = JTextField()
    private val txtAlamat = JTextField()
    private val txtTelepon = JTextField()

    private var model: DefaultTableModel? = null
    private var table: JTable? = null
    private var nomor = 1
    private val idList = mutableListOf<Int>() // untuk menyimpan id asli dari DB

    init {
        title = "Manajemen Data Pelanggan"
        setSize(750, 420)
        defaultCloseOperation = EXIT_ON_CLOSE
        setLocationRelativeTo(null)

        DatabaseHelper.initDatabase()
        initUI()
        loadData()
    }

    private fun initUI() {
        layout = BorderLayout(10, 10)

        // FORM INPUT
        val form = JPanel(GridLayout(3, 2, 5, 5))
        form.border = BorderFactory.createTitledBorder("Form Pelanggan")
        form.add(JLabel("Nama Pelanggan"))
        form.add(txtNama)
        form.add(JLabel("Alamat"))
        form.add(txtAlamat)
        form.add(JLabel("No. Telepon"))
        form.add(txtTelepon)
        add(form, BorderLayout.NORTH)

        // TABEL
        model = DefaultTableModel(arrayOf("No", "Nama", "Alamat", "Telepon"), 0)
        table = JTable(model)
        add(JScrollPane(table), BorderLayout.CENTER)

        // PANEL TOMBOL
        val panelBtn = JPanel(FlowLayout())
        val btnTambah = JButton("Simpan")
        val btnUbah = JButton("Ubah")
        val btnHapus = JButton("Hapus")
        panelBtn.add(btnTambah)
        panelBtn.add(btnUbah)
        panelBtn.add(btnHapus)
        add(panelBtn, BorderLayout.SOUTH)

        // EVENT
        btnTambah.addActionListener { tambahData() }
        btnUbah.addActionListener { ubahData() }
        btnHapus.addActionListener { hapusData() }

        // Klik baris tabel untuk isi form
        table!!.selectionModel.addListSelectionListener {
            val row = table!!.selectedRow
            if (row >= 0) {
                txtNama.text = table!!.getValueAt(row, 1).toString()
                txtAlamat.text = table!!.getValueAt(row, 2).toString()
                txtTelepon.text = table!!.getValueAt(row, 3).toString()
            }
        }
    }

    private fun tambahData() {
        if (txtNama.text.isEmpty() || txtAlamat.text.isEmpty() || txtTelepon.text.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Semua data wajib diisi!")
            return
        }

        DatabaseHelper.simpanPelanggan(txtNama.text, txtAlamat.text, txtTelepon.text)
        loadData()
        resetForm()
    }

    private fun ubahData() {
        val row = table!!.selectedRow
        if (row >= 0) {
            val id = idList[row]
            DatabaseHelper.ubahPelanggan(id, txtNama.text, txtAlamat.text, txtTelepon.text)
            loadData()
            resetForm()
        } else {
            JOptionPane.showMessageDialog(this, "Pilih data yang akan diubah!")
        }
    }

    private fun hapusData() {
        val row = table!!.selectedRow
        if (row >= 0) {
            val id = idList[row]
            DatabaseHelper.hapusPelanggan(id)
            loadData()
            resetForm()
        } else {
            JOptionPane.showMessageDialog(this, "Pilih data yang akan dihapus!")
        }
    }

    private fun resetForm() {
        txtNama.text = ""
        txtAlamat.text = ""
        txtTelepon.text = ""
        table!!.clearSelection()
    }

    private fun loadData() {
        model!!.rowCount = 0
        idList.clear()
        val rs = DatabaseHelper.getAllPelanggan()
        var nomor = 1
        while (rs != null && rs.next()) {
            val id = rs.getInt("id")
            idList.add(id)
            model!!.addRow(arrayOf(nomor++, rs.getString("nama"), rs.getString("alamat"), rs.getString("telepon")))
        }
    }
}
