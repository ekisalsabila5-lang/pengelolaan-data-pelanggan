package org.example.app

import java.sql.Connection
import java.sql.DriverManager
import java.sql.ResultSet
import java.sql.SQLException

object DatabaseHelper {
    private const val DB_URL = "jdbc:sqlite:pelanggan.db"
    private var connection: Connection? = null

    // Inisialisasi database
    fun initDatabase() {
        try {
            connection = DriverManager.getConnection(DB_URL)
            val stmt = connection!!.createStatement()
            val sql = """
                CREATE TABLE IF NOT EXISTS pelanggan (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    nama TEXT NOT NULL,
                    alamat TEXT NOT NULL,
                    telepon TEXT NOT NULL
                );
            """.trimIndent()
            stmt.execute(sql)
            stmt.close()
            println("Database siap digunakan!")
        } catch (e: SQLException) {
            e.printStackTrace()
        }
    }

    // Simpan data
    fun simpanPelanggan(nama: String, alamat: String, telepon: String) {
        val sql = "INSERT INTO pelanggan (nama, alamat, telepon) VALUES (?, ?, ?)"
        try {
            val pstmt = connection!!.prepareStatement(sql)
            pstmt.setString(1, nama)
            pstmt.setString(2, alamat)
            pstmt.setString(3, telepon)
            pstmt.executeUpdate()
            pstmt.close()
        } catch (e: SQLException) {
            e.printStackTrace()
        }
    }

    // Ambil semua data
    fun getAllPelanggan(): ResultSet? {
        val sql = "SELECT * FROM pelanggan"
        return try {
            val stmt = connection!!.createStatement()
            stmt.executeQuery(sql)
        } catch (e: SQLException) {
            e.printStackTrace()
            null
        }
    }

    // Ubah data berdasarkan ID
    fun ubahPelanggan(id: Int, nama: String, alamat: String, telepon: String) {
        val sql = "UPDATE pelanggan SET nama = ?, alamat = ?, telepon = ? WHERE id = ?"
        try {
            val pstmt = connection!!.prepareStatement(sql)
            pstmt.setString(1, nama)
            pstmt.setString(2, alamat)
            pstmt.setString(3, telepon)
            pstmt.setInt(4, id)
            pstmt.executeUpdate()
            pstmt.close()
        } catch (e: SQLException) {
            e.printStackTrace()
        }
    }

    // Hapus data berdasarkan ID
    fun hapusPelanggan(id: Int) {
        val sql = "DELETE FROM pelanggan WHERE id = ?"
        try {
            val pstmt = connection!!.prepareStatement(sql)
            pstmt.setInt(1, id)
            pstmt.executeUpdate()
            pstmt.close()
        } catch (e: SQLException) {
            e.printStackTrace()
        }
    }
}
