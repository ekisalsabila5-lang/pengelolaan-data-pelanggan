package org.example.app

import javax.swing.SwingUtilities

fun main() {
    SwingUtilities.invokeLater {
        PengelolaanDataPelangganV2().isVisible = true
    }
}
